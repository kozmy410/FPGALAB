module Lab3Ex1(input clk, key1,
            output reg [7:0] seg,
            output [3:0] dig,
            output reg led1);

reg [19:0] debounce_cnt = 0;
reg clean_key = 1;           

reg [3:0] n = 0;
reg old = 1;

initial led1 = 0;

assign dig = 4'b1110;        

always @(posedge clk) begin
    if (key1 == clean_key) begin
        debounce_cnt <= 0;   
    end else begin
        debounce_cnt <= debounce_cnt + 1; 
        if (debounce_cnt == 20'd1000000) begin 
            clean_key <= key1; 
            debounce_cnt <= 0;
        end
    end
end

always @(posedge clk) begin
    old <= clean_key; 
    if (old & ~clean_key) begin
        n <= (n==9) ? 0 : n+1;
        
        if (n == 9) begin
            led1 <= ~led1; 
        end
    end
end

always @* begin
    case(n)
        0: seg = 8'hC0;   1: seg = 8'hF9;
        2: seg = 8'hA4;   3: seg = 8'hB0;
        4: seg = 8'h99;   5: seg = 8'h92;
        6: seg = 8'h82;   7: seg = 8'hF8;
        8: seg = 8'h80;   9: seg = 8'h90;
        default: seg = 8'hFF;
    endcase
end

endmodule